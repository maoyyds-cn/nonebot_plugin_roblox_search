import asyncio
import time
from nonebot import on_command
from nonebot.adapters.onebot.v11 import Event, MessageSegment
from .render_utils import menu_to_image

roblox_menu = on_command("菜单", aliases={"帮助", "/菜单"}, priority=5, block=True)

@roblox_menu.handle()
async def handle_menu(event: Event):
    start_time = time.time()
    try:
        img_bytes = await menu_to_image()
        await roblox_menu.finish(MessageSegment.image(img_bytes))
    except Exception as e:
        print(f"[菜单生成错误]: {e}")
        await roblox_menu.finish("菜单生成失败，请稍后重试")
    finally:
        print(f"[DEBUG] 菜单生成耗时: {time.time()-start_time:.2f}s")
