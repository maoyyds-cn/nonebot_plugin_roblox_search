import asyncio
import logging
from datetime import datetime
from nonebot import on_keyword
from nonebot.adapters.onebot.v11 import MessageSegment, ActionFailed
from nonebot.exception import FinishedException
from .http_utils import http_get

logger = logging.getLogger(__name__)

roblox_game_id_search = on_keyword(["游戏ID搜索", "/游戏ID搜索"], priority=5, block=True)

async def get_game_info(game_id):
    url = f"https://games.rotunnel.com/v1/games?placeIds={game_id}"
    data = await http_get(url)
    if data and data.get("data"):
        return data["data"][0]
    return None

async def get_game_servers(game_id):
    url = f"https://games.rotunnel.com/v1/games/{game_id}/servers/Public?limit=10&sortOrder=Asc"
    data = await http_get(url)
    if data:
        return data.get("data", [])
    return []

async def get_game_icon(game_id):
    url = f"https://thumbnails.rotunnel.com/v1/games/icons?gameIds={game_id}&size=512x512&format=Png"
    data = await http_get(url)
    if data and data.get("data"):
        return data["data"][0].get("imageUrl")
    return None

@roblox_game_id_search.handle()
async def handle_search(event):
    msg = str(event.get_message())
    game_id = msg.replace("游戏ID搜索", "").replace("/", "").strip()
    
    if not game_id.isdigit():
        await roblox_game_id_search.finish("请输入有效的游戏ID（数字）")
    
    await roblox_game_id_search.send("稍等，正在查询Roblox游戏信息...")
    
    try:
        tasks = [
            get_game_info(game_id),
            get_game_servers(game_id),
            get_game_icon(game_id),
        ]
        
        results = await asyncio.gather(*tasks)
        game_info, servers, icon_url = results
        
        if not game_info:
            await roblox_game_id_search.finish("未找到该游戏，请检查游戏ID是否正确！")
        
        name = game_info.get("name", "未知")
        description = game_info.get("description", "")
        visits = game_info.get("visits", 0)
        favorites = game_info.get("favorites", 0)
        created = game_info.get("created")
        updated = game_info.get("updated")
        max_players = game_info.get("maxPlayers", 0)
        
        servers_text = ""
        if servers:
            for server in servers[:3]:
                players = server.get("playing", 0)
                ping = server.get("ping", 0)
                servers_text += f"🎮 在线人数：{players}/{max_players} | 延迟：{ping}ms\n"
        else:
            servers_text = "暂无公开服务器信息\n"
        
        if created:
            create_date = datetime.strptime(created, "%Y-%m-%dT%H:%M:%S.%fZ")
        else:
            create_date = None
        
        if updated:
            update_date = datetime.strptime(updated, "%Y-%m-%dT%H:%M:%S.%fZ")
        else:
            update_date = None
        
        output = f"🎮 Roblox 游戏信息查询\n\n"
        output += f"📌 游戏名：{name}\n"
        output += f"🆔 游戏ID：{game_id}\n"
        output += f"👁️ 总访问量：{visits:,}\n"
        output += f"❤️ 收藏数：{favorites:,}\n"
        output += f"📅 创建时间：{create_date.strftime('%Y-%m-%d') if create_date else '未知'}\n"
        output += f"🔄 更新时间：{update_date.strftime('%Y-%m-%d') if update_date else '未知'}\n\n"
        output += f"📝 游戏描述：\n{description[:200]}{'......' if len(description)>200 else ''}\n\n"
        output += f"🌐 公开服务器(前3个)：\n{servers_text}"
        
        messages = []
        if icon_url:
            try:
                import requests
                response = requests.get(icon_url, timeout=5)
                if response.status_code == 200:
                    messages.append(MessageSegment.image(response.content))
            except:
                pass
        
        messages.append(output)
        await roblox_game_id_search.finish(messages)
    
    except ActionFailed:
        await roblox_game_id_search.finish("消息发送失败，可能是bot被禁言或对方已离线")
    except FinishedException:
        pass
    except Exception as e:
        logger.error(f"查询游戏信息失败: {e}")
        await roblox_game_id_search.finish("查询失败，请稍后重试")
