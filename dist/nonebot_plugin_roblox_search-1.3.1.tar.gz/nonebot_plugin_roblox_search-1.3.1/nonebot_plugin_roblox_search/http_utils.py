import asyncio
import json
import logging
import os

logger = logging.getLogger(__name__)

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
}

TIMEOUT = 30

MAX_CONCURRENT_REQUESTS = 3
MAX_RETRIES = 3
BASE_RETRY_DELAY = 1.0

semaphore = asyncio.Semaphore(MAX_CONCURRENT_REQUESTS)

def get_curl_command():
    return "curl" if os.name == "posix" else "curl.exe"

def encode_url(url):
    from urllib.parse import quote
    parts = url.split('?')
    if len(parts) == 2:
        base, query = parts
        query_parts = []
        for param in query.split('&'):
            if '=' in param:
                key, value = param.split('=', 1)
                query_parts.append(f"{key}={quote(value)}")
            else:
                query_parts.append(param)
        return f"{base}?{'&'.join(query_parts)}"
    return url

async def curl_request(url: str, method: str = "GET", data: dict = None, headers: dict = None):
    async with semaphore:
        curl_args = [get_curl_command(), "-s", "-i", "-X", method]
        
        all_headers = HEADERS.copy()
        if headers:
            all_headers.update(headers)
        
        for key, value in all_headers.items():
            curl_args.append("-H")
            curl_args.append(f"{key}: {value}")
        
        url = encode_url(url)
        curl_args.append(url)
        
        if data:
            json_data = json.dumps(data)
            curl_args.append("-d")
            curl_args.append(json_data)
        
        for attempt in range(MAX_RETRIES):
            try:
                process = await asyncio.create_subprocess_exec(
                    *curl_args,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await process.communicate()
                
                if stdout:
                    try:
                        response_text = stdout.decode('utf-8', errors='ignore')
                        lines = response_text.split('\n')
                        
                        status_line = lines[0] if lines else ''
                        status_code = 0
                        if 'HTTP/' in status_line:
                            parts = status_line.split()
                            if len(parts) > 1:
                                status_code = int(parts[1])
                        
                        headers_end = response_text.find('\r\n\r\n')
                        if headers_end == -1:
                            headers_end = response_text.find('\n\n')
                        
                        if headers_end != -1:
                            body = response_text[headers_end + 4:]
                        else:
                            body = response_text
                        
                        try:
                            return json.loads(body)
                        except json.JSONDecodeError:
                            if status_code == 200:
                                return {"success": True, "body": body}
                            else:
                                logger.error(f"[HTTP Error] `{url}`: status {status_code}")
                                return None
                    except Exception as e:
                        logger.error(f"[CURL Exception] `{url}`: {e}")
                        if attempt < MAX_RETRIES - 1:
                            delay = BASE_RETRY_DELAY * (2 ** attempt)
                            logger.info(f"[Request Failed] `{url}`, retry {attempt + 1}/{MAX_RETRIES}, waiting {delay:.2f}s")
                            await asyncio.sleep(delay)
                            continue
                        return None
                else:
                    if attempt < MAX_RETRIES - 1:
                        delay = BASE_RETRY_DELAY * (2 ** attempt)
                        logger.info(f"[Request Failed] `{url}`, retry {attempt + 1}/{MAX_RETRIES}, waiting {delay:.2f}s")
                        await asyncio.sleep(delay)
                        continue
                    logger.error(f"[HTTP Error] `{url}`: status 0")
                    return None
            except Exception as e:
                logger.error(f"[CURL Exception] `{url}`: {e}")
                if attempt < MAX_RETRIES - 1:
                    delay = BASE_RETRY_DELAY * (2 ** attempt)
                    logger.info(f"[Request Failed] `{url}`, retry {attempt + 1}/{MAX_RETRIES}, waiting {delay:.2f}s")
                    await asyncio.sleep(delay)
                    continue
                return None

async def http_get(url: str, headers: dict = None):
    return await curl_request(url, method="GET", headers=headers)

async def http_post(url: str, data: dict = None, headers: dict = None):
    return await curl_request(url, method="POST", data=data, headers=headers)
