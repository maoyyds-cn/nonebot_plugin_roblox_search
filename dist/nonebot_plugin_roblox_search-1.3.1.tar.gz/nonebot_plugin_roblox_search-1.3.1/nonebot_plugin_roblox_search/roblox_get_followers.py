import asyncio
import logging
from nonebot import on_keyword
from nonebot.adapters.onebot.v11 import ActionFailed
from nonebot.exception import FinishedException
from .http_utils import http_get, http_post

logger = logging.getLogger(__name__)

roblox_get_followers = on_keyword(["获取粉丝列表", "/获取粉丝列表"], priority=5, block=True)

async def get_followers(user_id):
    url = f"https://friends.rotunnel.com/v1/users/{user_id}/followers"
    data = await http_get(url)
    if data:
        return data.get("data", [])
    return []

async def get_user_info(user_id):
    url = f"https://users.rotunnel.com/v1/users/{user_id}"
    data = await http_get(url)
    return data

@roblox_get_followers.handle()
async def handle_search(event):
    msg = str(event.get_message())
    user_id = msg.replace("获取粉丝列表", "").replace("/", "").strip()
    
    if not user_id.isdigit():
        await roblox_get_followers.finish("请输入有效的用户ID（数字）")
    
    await roblox_get_followers.send("稍等，正在获取粉丝列表...")
    
    try:
        followers = await get_followers(user_id)
        
        if not followers:
            await roblox_get_followers.finish("未找到粉丝列表，或该用户没有粉丝！")
        
        user_ids = [follower.get("id") for follower in followers[:10]]
        
        if user_ids:
            url = "https://users.rotunnel.com/v1/users"
            data = await http_post(url, data={"userIds": user_ids, "excludeBannedUsers": False})
            user_info_map = {}
            if data and data.get("data"):
                for user in data["data"]:
                    user_info_map[user.get("id")] = user
        else:
            user_info_map = {}
        
        output = f"👥 用户 {user_id} 的粉丝列表(前10个)：\n\n"
        for idx, follower in enumerate(followers[:10], 1):
            follower_id = follower.get("id")
            follower_info = user_info_map.get(follower_id, {})
            username = follower_info.get("name", "未知")
            display_name = follower_info.get("displayName", "未知")
            output += f"{idx}) {username}（{display_name}）｜ID：{follower_id}\n"
        
        await roblox_get_followers.finish(output)
    
    except ActionFailed:
        await roblox_get_followers.finish("消息发送失败，可能是bot被禁言或对方已离线")
    except FinishedException:
        pass
    except Exception as e:
        logger.error(f"获取粉丝列表失败: {e}")
        await roblox_get_followers.finish("获取失败，请稍后重试")
