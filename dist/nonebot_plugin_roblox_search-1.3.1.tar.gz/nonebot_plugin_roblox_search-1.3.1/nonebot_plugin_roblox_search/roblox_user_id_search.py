import asyncio
import logging
from datetime import datetime
from nonebot import on_keyword
from nonebot.adapters.onebot.v11 import MessageSegment, ActionFailed
from nonebot.exception import FinishedException
from .http_utils import http_get, http_post

logger = logging.getLogger(__name__)

roblox_user_id_search = on_keyword(["用户ID搜索", "/用户ID搜索"], priority=5, block=True)

async def get_user_by_id(user_id):
    url = f"https://users.rotunnel.com/v1/users/{user_id}"
    data = await http_get(url)
    return data

async def get_presence(user_id):
    url = "https://presence.rotunnel.com/v1/presence/users"
    data = await http_post(url, data={"userIds": [user_id]})
    if data.get("userPresences"):
        return data["userPresences"][0]
    return None

async def get_groups(user_id):
    url = f"https://groups.rotunnel.com/v1/users/{user_id}/groups/roles?limit=10"
    data = await http_get(url)
    if data:
        return data.get("data", [])
    return []

async def get_friend_count(user_id):
    url = f"https://friends.rotunnel.com/v1/users/{user_id}/friends/count"
    data = await http_get(url)
    if data:
        return data.get("count", 0)
    return 0

async def get_follower_count(user_id):
    url = f"https://friends.rotunnel.com/v1/users/{user_id}/followers/count"
    data = await http_get(url)
    if data:
        return data.get("count", 0)
    return 0

async def get_following_count(user_id):
    url = f"https://friends.rotunnel.com/v1/users/{user_id}/followings/count"
    data = await http_get(url)
    if data:
        return data.get("count", 0)
    return 0

async def get_avatar_headshot(user_id):
    url = f"https://thumbnails.rotunnel.com/v1/users/avatar-headshot?userIds={user_id}&size=150x150&format=Png&isCircular=false"
    data = await http_get(url)
    if data and data.get("data"):
        return data["data"][0].get("imageUrl")
    return None

async def get_avatar(user_id):
    url = f"https://thumbnails.rotunnel.com/v1/users/avatar?userIds={user_id}&size=420x420&format=Png"
    data = await http_get(url)
    if data and data.get("data"):
        return data["data"][0].get("imageUrl")
    return None

@roblox_user_id_search.handle()
async def handle_search(event):
    msg = str(event.get_message())
    user_id = msg.replace("用户ID搜索", "").replace("/", "").strip()
    
    if not user_id.isdigit():
        await roblox_user_id_search.finish("请输入有效的用户ID（数字）")
    
    await roblox_user_id_search.send("稍等，正在查询Roblox用户信息...")
    
    try:
        tasks = [
            get_user_by_id(user_id),
            get_presence(user_id),
            get_groups(user_id),
            get_friend_count(user_id),
            get_follower_count(user_id),
            get_following_count(user_id),
            get_avatar_headshot(user_id),
            get_avatar(user_id),
        ]
        
        results = await asyncio.gather(*tasks)
        user_info, presence, groups, friend_count, follower_count, following_count, headshot_url, avatar_url = results
        
        if not user_info or "errors" in user_info:
            await roblox_user_id_search.finish("未找到该用户，请检查用户ID是否正确！")
        
        username = user_info.get("name", "未知")
        display_name = user_info.get("displayName", "未知")
        created_at = user_info.get("created")
        description = user_info.get("description", "")
        is_banned = user_info.get("isBanned", False)
        
        status = presence.get("userPresenceType", 0) if presence else 0
        status_text = {0: "离线", 1: "在线", 2: "游戏中", 3: "工作室中"}.get(status, "未知")
        
        last_location = presence.get("lastLocation", "") if presence else ""
        
        if created_at:
            created_date = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ")
            now = datetime.utcnow()
            delta = now - created_date
            days = delta.days
            years = days // 365
            months = (days % 365) // 30
            days_remaining = days % 30
            register_text = f"{created_date.strftime('%Y-%m-%d')}\n⏳ 注册时长：{years}年{months}月{days_remaining}天（共{days}天）"
        else:
            register_text = "未知"
        
        output = f"📄 Roblox 用户信息查询\n\n"
        output += f"👤 用户名：{username}\n"
        output += f"🏷️ 展示名：{display_name}\n"
        output += f"🆔 用户ID：{user_id}\n"
        output += f"📅 注册日期：{register_text}\n"
        output += f"👥 好友：{friend_count} | 关注：{following_count} | 粉丝：{follower_count}\n"
        output += f"🟢 在线状态：{status_text}\n"
        output += f"📍 当前位置：{last_location if last_location else '未知'}\n"
        output += f"🚫 账号封禁：{'是' if is_banned else '否'}\n"
        
        if description:
            output += f"\n📝 用户简介：\n{description[:200]}{'......' if len(description)>200 else ''}\n"
        
        if groups:
            output += f"\n🏠 已加入群组(前10个)：\n"
            for idx, group in enumerate(groups[:10], 1):
                group_name = group.get("group", {}).get("name", "未知")
                role = group.get("role", {}).get("name", "未知")
                group_id = group.get("group", {}).get("id", 0)
                output += f"{idx}) {group_name}｜职位:{role}\n"
                output += f"   群组ID：{group_id}\n"
        
        messages = []
        if headshot_url:
            try:
                import requests
                response = requests.get(headshot_url, timeout=5)
                if response.status_code == 200:
                    messages.append(MessageSegment.image(response.content))
            except:
                pass
        
        if avatar_url:
            try:
                import requests
                response = requests.get(avatar_url, timeout=5)
                if response.status_code == 200:
                    messages.append(MessageSegment.image(response.content))
            except:
                pass
        
        messages.append(output)
        
        await roblox_user_id_search.finish(messages)
    
    except ActionFailed:
        await roblox_user_id_search.finish("消息发送失败，可能是bot被禁言或对方已离线")
    except FinishedException:
        pass
    except Exception as e:
        logger.error(f"查询用户信息失败: {e}")
        await roblox_user_id_search.finish("查询失败，请稍后重试")
