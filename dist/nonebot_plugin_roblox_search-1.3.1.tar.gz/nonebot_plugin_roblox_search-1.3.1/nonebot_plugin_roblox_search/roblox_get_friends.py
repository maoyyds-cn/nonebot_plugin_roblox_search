import asyncio
import logging
from nonebot import on_keyword
from nonebot.adapters.onebot.v11 import ActionFailed
from nonebot.exception import FinishedException
from .http_utils import http_get, http_post

logger = logging.getLogger(__name__)

roblox_get_friends = on_keyword(["获取好友列表", "/获取好友列表"], priority=5, block=True)

async def get_friends(user_id):
    url = f"https://friends.rotunnel.com/v1/users/{user_id}/friends"
    data = await http_get(url)
    if data:
        return data.get("data", [])
    return []

async def get_user_info(user_id):
    url = f"https://users.rotunnel.com/v1/users/{user_id}"
    data = await http_get(url)
    return data

@roblox_get_friends.handle()
async def handle_search(event):
    msg = str(event.get_message())
    user_id = msg.replace("获取好友列表", "").replace("/", "").strip()
    
    if not user_id.isdigit():
        await roblox_get_friends.finish("请输入有效的用户ID（数字）")
    
    await roblox_get_friends.send("稍等，正在获取好友列表...")
    
    try:
        friends = await get_friends(user_id)
        
        if not friends:
            await roblox_get_friends.finish("未找到好友列表，或该用户没有好友！")
        
        user_ids = [friend.get("id") for friend in friends[:10]]
        
        if user_ids:
            url = "https://users.rotunnel.com/v1/users"
            data = await http_post(url, data={"userIds": user_ids, "excludeBannedUsers": False})
            user_info_map = {}
            if data and data.get("data"):
                for user in data["data"]:
                    user_info_map[user.get("id")] = user
        else:
            user_info_map = {}
        
        output = f"👥 用户 {user_id} 的好友列表(前10个)：\n\n"
        for idx, friend in enumerate(friends[:10], 1):
            friend_id = friend.get("id")
            friend_info = user_info_map.get(friend_id, {})
            username = friend_info.get("name", "未知")
            display_name = friend_info.get("displayName", "未知")
            output += f"{idx}) {username}（{display_name}）｜ID：{friend_id}\n"
        
        await roblox_get_friends.finish(output)
    
    except ActionFailed:
        await roblox_get_friends.finish("消息发送失败，可能是bot被禁言或对方已离线")
    except FinishedException:
        pass
    except Exception as e:
        logger.error(f"获取好友列表失败: {e}")
        await roblox_get_friends.finish("获取失败，请稍后重试")
