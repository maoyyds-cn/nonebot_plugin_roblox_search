import asyncio
import logging
from datetime import datetime
from nonebot import on_keyword
from nonebot.adapters.onebot.v11 import MessageSegment, ActionFailed
from nonebot.exception import FinishedException
from .http_utils import http_get

logger = logging.getLogger(__name__)

roblox_game_name_search = on_keyword(["游戏名搜索", "/游戏名搜索"], priority=5, block=True)

async def search_games(game_name):
    url = f"https://games.rotunnel.com/v1/games/list?keyword={game_name}&limit=5"
    data = await http_get(url)
    if data and data.get("data"):
        return data["data"]
    return []

async def get_game_icon(game_id):
    url = f"https://thumbnails.rotunnel.com/v1/games/icons?gameIds={game_id}&size=512x512&format=Png"
    data = await http_get(url)
    if data and data.get("data"):
        return data["data"][0].get("imageUrl")
    return None

@roblox_game_name_search.handle()
async def handle_search(event):
    msg = str(event.get_message())
    game_name = msg.replace("游戏名搜索", "").replace("/", "").strip()
    
    if not game_name:
        await roblox_game_name_search.finish("请输入游戏名，格式：游戏名搜索 [游戏名]")
    
    await roblox_game_name_search.send("稍等，正在搜索Roblox游戏...")
    
    try:
        games = await search_games(game_name)
        
        if not games:
            await roblox_game_name_search.finish("未找到相关游戏，请尝试其他关键词！")
        
        game = games[0]
        game_id = game.get("placeId", game.get("id", 0))
        name = game.get("name", "未知")
        description = game.get("description", "")
        visits = game.get("visits", 0)
        favorites = game.get("favorites", 0)
        created = game.get("created")
        updated = game.get("updated")
        
        icon_url = await get_game_icon(game_id)
        
        if created:
            create_date = datetime.strptime(created, "%Y-%m-%dT%H:%M:%S.%fZ")
        else:
            create_date = None
        
        if updated:
            update_date = datetime.strptime(updated, "%Y-%m-%dT%H:%M:%S.%fZ")
        else:
            update_date = None
        
        output = f"🎮 Roblox 游戏搜索结果\n\n"
        output += f"📌 游戏名：{name}\n"
        output += f"🆔 游戏ID：{game_id}\n"
        output += f"👁️ 总访问量：{visits:,}\n"
        output += f"❤️ 收藏数：{favorites:,}\n"
        output += f"📅 创建时间：{create_date.strftime('%Y-%m-%d') if create_date else '未知'}\n"
        output += f"🔄 更新时间：{update_date.strftime('%Y-%m-%d') if update_date else '未知'}\n\n"
        output += f"📝 游戏描述：\n{description[:300]}{'......' if len(description)>300 else ''}"
        
        messages = []
        if icon_url:
            try:
                import requests
                response = requests.get(icon_url, timeout=5)
                if response.status_code == 200:
                    messages.append(MessageSegment.image(response.content))
            except:
                pass
        
        messages.append(output)
        await roblox_game_name_search.finish(messages)
    
    except ActionFailed:
        await roblox_game_name_search.finish("消息发送失败，可能是bot被禁言或对方已离线")
    except FinishedException:
        pass
    except Exception as e:
        logger.error(f"搜索游戏失败: {e}")
        await roblox_game_name_search.finish("搜索失败，请稍后重试")
