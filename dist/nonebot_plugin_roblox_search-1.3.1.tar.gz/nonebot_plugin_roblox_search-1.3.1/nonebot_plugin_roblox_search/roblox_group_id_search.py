import asyncio
import logging
from datetime import datetime
from nonebot import on_keyword
from nonebot.adapters.onebot.v11 import MessageSegment, ActionFailed
from nonebot.exception import FinishedException
from .http_utils import http_get

logger = logging.getLogger(__name__)

roblox_group_id_search = on_keyword(["群组ID搜索", "/群组ID搜索"], priority=5, block=True)

async def get_group_info(group_id):
    url = f"https://groups.rotunnel.com/v1/groups/{group_id}"
    data = await http_get(url)
    return data

async def get_group_roles(group_id):
    url = f"https://groups.rotunnel.com/v1/groups/{group_id}/roles"
    data = await http_get(url)
    if data:
        return data.get("roles", [])
    return []

async def get_group_icon(group_id):
    url = f"https://thumbnails.rotunnel.com/v1/groups/icons?groupIds={group_id}&size=512x512&format=Png"
    data = await http_get(url)
    if data and data.get("data"):
        return data["data"][0].get("imageUrl")
    return None

@roblox_group_id_search.handle()
async def handle_search(event):
    msg = str(event.get_message())
    group_id = msg.replace("群组ID搜索", "").replace("/", "").strip()
    
    if not group_id.isdigit():
        await roblox_group_id_search.finish("请输入有效的群组ID（数字）")
    
    await roblox_group_id_search.send("稍等，正在查询Roblox群组信息...")
    
    try:
        tasks = [
            get_group_info(group_id),
            get_group_roles(group_id),
            get_group_icon(group_id),
        ]
        
        results = await asyncio.gather(*tasks)
        group_info, roles, icon_url = results
        
        if not group_info or "errors" in group_info:
            await roblox_group_id_search.finish("未找到该群组，请检查群组ID是否正确！")
        
        name = group_info.get("name", "未知")
        description = group_info.get("description", "")
        member_count = group_info.get("memberCount", 0)
        created = group_info.get("created")
        is_public = group_info.get("publicEntryAllowed", False)
        
        owner = group_info.get("owner", {})
        owner_name = owner.get("username", "未知")
        
        roles_text = ""
        if roles:
            for role in roles[:10]:
                role_name = role.get("name", "未知")
                rank = role.get("rank", 0)
                member_count_role = role.get("memberCount", 0)
                roles_text += f"🏆 {role_name}（等级{rank}）：{member_count_role}人\n"
        else:
            roles_text = "暂无职位信息\n"
        
        if created:
            create_date = datetime.strptime(created, "%Y-%m-%dT%H:%M:%S.%fZ")
        else:
            create_date = None
        
        output = f"🏢 Roblox 群组信息查询\n\n"
        output += f"📌 群组名：{name}\n"
        output += f"🆔 群组ID：{group_id}\n"
        output += f"👥 成员数量：{member_count:,}\n"
        output += f"👤 群主：{owner_name}\n"
        output += f"📅 创建时间：{create_date.strftime('%Y-%m-%d') if create_date else '未知'}\n"
        output += f"🌐 是否公开：{'是' if is_public else '否'}\n\n"
        output += f"📝 群组描述：\n{description[:200]}{'......' if len(description)>200 else ''}\n\n"
        output += f"🏆 职位列表(前10个)：\n{roles_text}"
        
        messages = []
        if icon_url:
            try:
                import requests
                response = requests.get(icon_url, timeout=5)
                if response.status_code == 200:
                    messages.append(MessageSegment.image(response.content))
            except:
                pass
        
        messages.append(output)
        await roblox_group_id_search.finish(messages)
    
    except ActionFailed:
        await roblox_group_id_search.finish("消息发送失败，可能是bot被禁言或对方已离线")
    except FinishedException:
        pass
    except Exception as e:
        logger.error(f"查询群组信息失败: {e}")
        await roblox_group_id_search.finish("查询失败，请稍后重试")
