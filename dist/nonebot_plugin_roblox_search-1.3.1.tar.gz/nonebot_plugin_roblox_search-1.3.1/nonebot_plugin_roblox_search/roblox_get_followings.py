import asyncio
import logging
from nonebot import on_keyword
from nonebot.adapters.onebot.v11 import ActionFailed
from nonebot.exception import FinishedException
from .http_utils import http_get, http_post

logger = logging.getLogger(__name__)

roblox_get_followings = on_keyword(["获取关注列表", "/获取关注列表"], priority=5, block=True)

async def get_followings(user_id):
    url = f"https://friends.rotunnel.com/v1/users/{user_id}/followings"
    data = await http_get(url)
    if data:
        return data.get("data", [])
    return []

async def get_user_info(user_id):
    url = f"https://users.rotunnel.com/v1/users/{user_id}"
    data = await http_get(url)
    return data

@roblox_get_followings.handle()
async def handle_search(event):
    msg = str(event.get_message())
    user_id = msg.replace("获取关注列表", "").replace("/", "").strip()
    
    if not user_id.isdigit():
        await roblox_get_followings.finish("请输入有效的用户ID（数字）")
    
    await roblox_get_followings.send("稍等，正在获取关注列表...")
    
    try:
        followings = await get_followings(user_id)
        
        if not followings:
            await roblox_get_followings.finish("未找到关注列表，或该用户没有关注任何人！")
        
        user_ids = [following.get("id") for following in followings[:10]]
        
        if user_ids:
            url = "https://users.rotunnel.com/v1/users"
            data = await http_post(url, data={"userIds": user_ids, "excludeBannedUsers": False})
            user_info_map = {}
            if data and data.get("data"):
                for user in data["data"]:
                    user_info_map[user.get("id")] = user
        else:
            user_info_map = {}
        
        output = f"👥 用户 {user_id} 的关注列表(前10个)：\n\n"
        for idx, following in enumerate(followings[:10], 1):
            following_id = following.get("id")
            following_info = user_info_map.get(following_id, {})
            username = following_info.get("name", "未知")
            display_name = following_info.get("displayName", "未知")
            output += f"{idx}) {username}（{display_name}）｜ID：{following_id}\n"
        
        await roblox_get_followings.finish(output)
    
    except ActionFailed:
        await roblox_get_followings.finish("消息发送失败，可能是bot被禁言或对方已离线")
    except FinishedException:
        pass
    except Exception as e:
        logger.error(f"获取关注列表失败: {e}")
        await roblox_get_followings.finish("获取失败，请稍后重试")
