import asyncio
import logging
from nonebot import on_keyword
from nonebot.adapters.onebot.v11 import MessageSegment, ActionFailed
from nonebot.exception import FinishedException
from .render_utils import menu_to_image

logger = logging.getLogger(__name__)

roblox_menu = on_keyword(["菜单", "/菜单"], priority=5, block=True)

@roblox_menu.handle()
async def handle_menu(event):
    try:
        img_data = await menu_to_image()
        await roblox_menu.finish(MessageSegment.image(img_data))
    except ActionFailed:
        await roblox_menu.finish("消息发送失败，可能是bot被禁言或对方已离线")
    except FinishedException:
        pass
    except Exception as e:
        logger.error(f"生成菜单失败: {e}")
        menu_text = """🎮 Roblox 查询机器人 - 功能菜单

🔍 用户查询
- 用户名搜索 [用户名]
- 用户ID搜索 [数字ID]

🏢 群组查询
- 群组名搜索 [群组名]
- 群组ID搜索 [数字ID]

🎮 游戏查询
- 游戏名搜索 [游戏名]
- 游戏ID搜索 [数字ID]

👥 社交查询
- 获取好友列表 [用户ID]
- 获取粉丝列表 [用户ID]
- 获取关注列表 [用户ID]"""
        await roblox_menu.finish(menu_text)
