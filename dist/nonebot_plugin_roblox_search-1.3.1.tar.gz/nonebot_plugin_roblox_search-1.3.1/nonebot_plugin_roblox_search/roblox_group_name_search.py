import asyncio
import logging
from datetime import datetime
from nonebot import on_keyword
from nonebot.adapters.onebot.v11 import MessageSegment, ActionFailed
from nonebot.exception import FinishedException
from .http_utils import http_get

logger = logging.getLogger(__name__)

roblox_group_name_search = on_keyword(["群组名搜索", "/群组名搜索"], priority=5, block=True)

async def search_groups(group_name):
    url = f"https://groups.rotunnel.com/v1/groups/search?keyword={group_name}&limit=5"
    data = await http_get(url)
    if data and data.get("data"):
        return data["data"]
    return []

async def get_group_icon(group_id):
    url = f"https://thumbnails.rotunnel.com/v1/groups/icons?groupIds={group_id}&size=512x512&format=Png"
    data = await http_get(url)
    if data and data.get("data"):
        return data["data"][0].get("imageUrl")
    return None

@roblox_group_name_search.handle()
async def handle_search(event):
    msg = str(event.get_message())
    group_name = msg.replace("群组名搜索", "").replace("/", "").strip()
    
    if not group_name:
        await roblox_group_name_search.finish("请输入群组名，格式：群组名搜索 [群组名]")
    
    await roblox_group_name_search.send("稍等，正在搜索Roblox群组...")
    
    try:
        groups = await search_groups(group_name)
        
        if not groups:
            await roblox_group_name_search.finish("未找到相关群组，请尝试其他关键词！")
        
        group = groups[0]
        group_id = group.get("id", 0)
        name = group.get("name", "未知")
        description = group.get("description", "")
        member_count = group.get("memberCount", 0)
        created = group.get("created")
        is_public = group.get("publicEntryAllowed", False)
        
        owner = group.get("owner", {})
        owner_name = owner.get("username", "未知")
        
        icon_url = await get_group_icon(group_id)
        
        if created:
            create_date = datetime.strptime(created, "%Y-%m-%dT%H:%M:%S.%fZ")
        else:
            create_date = None
        
        output = f"🏢 Roblox 群组搜索结果\n\n"
        output += f"📌 群组名：{name}\n"
        output += f"🆔 群组ID：{group_id}\n"
        output += f"👥 成员数量：{member_count:,}\n"
        output += f"👤 群主：{owner_name}\n"
        output += f"📅 创建时间：{create_date.strftime('%Y-%m-%d') if create_date else '未知'}\n"
        output += f"🌐 是否公开：{'是' if is_public else '否'}\n\n"
        output += f"📝 群组描述：\n{description[:300]}{'......' if len(description)>300 else ''}"
        
        messages = []
        if icon_url:
            try:
                import requests
                response = requests.get(icon_url, timeout=5)
                if response.status_code == 200:
                    messages.append(MessageSegment.image(response.content))
            except:
                pass
        
        messages.append(output)
        await roblox_group_name_search.finish(messages)
    
    except ActionFailed:
        await roblox_group_name_search.finish("消息发送失败，可能是bot被禁言或对方已离线")
    except FinishedException:
        pass
    except Exception as e:
        logger.error(f"搜索群组失败: {e}")
        await roblox_group_name_search.finish("搜索失败，请稍后重试")
